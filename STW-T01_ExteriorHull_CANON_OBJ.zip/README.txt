STW-T01 STINGWASP EXTERIOR v8

Rebuilt around the supplied StingWasp design rather than a generic pod:
- low pointed compound cockpit/head
- broad wasp-like thorax
- visible waist transition
- engine-heavy aft abdomen
- layered flush dorsal exoskeletal armour
- integrated side machinery modules
- four recessed clustered drives
- port/starboard docking collars
- explicit closed ventral cargo-bay doors + ramp panel
- four splayed landing legs clear of cargo-door footprint
- NO WINGS

Exact overall envelope:
31.000 m length
10.500 m beam
8.200 m height
1 OBJ unit = 1 metre

Coordinates:
X port/starboard
Y down/up
Z aft/forward
